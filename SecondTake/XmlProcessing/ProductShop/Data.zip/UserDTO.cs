﻿namespace ProductShop
{
    internal class UserDTO
    {
    }
}