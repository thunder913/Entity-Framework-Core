﻿namespace BookShop.Data.Models.Enums
{
    public enum Genre
    {
        Biography = 1, Business = 2, Science = 3
    }
}
