﻿namespace CarDealer.DTO
{
    public class PartExportTDO
    {
        public string Name { get; set; }
        public string Price { get; set; }
    }
}
